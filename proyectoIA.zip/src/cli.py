import click
from config import Config
from optimize import optimize_strategy
from validate_params import validate_parameters
from train import train_models
from generate_signals import generate_signals
from tune_risk import tune_risk_confidence
from grid_search_sharpe import grid_search_sharpe
from evaluate import evaluate_performance

@click.group()
def cli():
    """CLI para orquestar el flujo completo de estrategias."""
    pass

@cli.command()
@click.argument('strategy')
def optimize(strategy: str):
    """Explorar espacio de parámetros para STRATEGY y generar param_grid CSV."""
    cfg = Config.load('config/config.yaml')
    optimize_strategy(strategy, cfg)
    click.echo(f"Optimización completada para {strategy}")

@cli.command()
def validar_parametros():
    """Validar y filtrar parámetros, actualizar config_master.json."""
    validate_parameters()
    click.echo("Parámetros validados y config_master.json actualizado.")

@cli.command()
def entrenar():
    """Entrenar modelos según config_master.json y guardar artefactos."""
    train_models()
    click.echo("Modelos entrenados y guardados.")

@cli.command()
@click.option('--periodo', default='last', help='Periodo para generación de señales (e.g., YYYY-MM-DD:YYYY-MM-DD)')
def generar_senales(periodo: str):
    """Generar señales usando modelos entrenados para el periodo especificado."""
    generate_signals(periodo)
    click.echo(f"Señales generadas para periodo {periodo}.")

@cli.command()
def tune_risk_confianza():
    """Ajustar riesgo USD y confianza para maximizar Sharpe por estrategia."""
    tune_risk_confidence()
    click.echo("Ajuste de riesgo y confianza completado.")

@cli.command()
def grid_search_sharpe():
    """Búsqueda fina sobre SL, TP y horizonte para optimizar métricas."""
    grid_search_sharpe()
    click.echo("Grid search fino completado.")

@cli.command()
def evaluar_rentabilidad():
    """Evaluar rentabilidad final: equity curves y métricas."""
    evaluate_performance()
    click.echo("Evaluación de rendimiento completada.")

if __name__ == '__main__':
    cli()
