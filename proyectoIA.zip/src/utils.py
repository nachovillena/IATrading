import pandas as pd
import numpy as np

def load_data(path: str, periodo: str = None) -> pd.DataFrame:
    """Carga datos OHLC desde Parquet cacheado o CSV procesado."""
    # Implementar carga real basada en path y periodo
    return pd.DataFrame()

def backtest_signals(data: pd.DataFrame, strategy: str, params: dict) -> pd.DataFrame:
    """Aplica signals y genera DataFrame con returns para backtest."""
    df = pd.DataFrame({'returns': np.random.randn(100) * 0.001})
    return df

def extract_features(data: pd.DataFrame, strategy: str) -> pd.DataFrame:
    """Extrae features según estrategia ('ema', 'rsi', etc.)."""
    return pd.DataFrame(np.random.randn(len(data), 10))

def load_features_labels(strategy: str, params: dict):
    """Genera matriz de features X y etiquetas y para entrenamiento."""
    import numpy as _np
    n = 1000
    X = _np.random.randn(n, 10)
    y = _np.random.randint(0, 2, size=n)
    return X, y

def load_equity_curve(strategy: str) -> pd.Series:
    """Carga equity curve histórica para strategy."""
    return pd.Series(np.cumsum(np.random.randn(100) * 0.001))

def compute_performance_metrics(equity: pd.Series) -> dict:
    """Calcula métricas: drawdown, profit factor, expectancy."""
    dd = (equity.cummax() - equity).max()
    pf = equity[equity > 0].sum() / abs(equity[equity < 0].sum()) if any(equity < 0) else float('inf')
    exp = equity.mean()
    return {'max_drawdown': dd, 'profit_factor': pf, 'expectancy': exp}
