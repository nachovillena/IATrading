import pandas as pd
import optuna
from pathlib import Path
from typing import Any, Dict
from utils import load_data, backtest_signals
from config import Config

PARAM_DIR = Path("parameters")
PARAM_DIR.mkdir(exist_ok=True)

def optimize_strategy(strategy: str, cfg: Config) -> None:
    data = load_data(cfg.data_paths['raw'])
    space = cfg.parameters.get(strategy, {})

    def objective(trial: optuna.Trial) -> float:
        params = {k: trial.suggest_uniform(k, *v) if isinstance(v, list) else trial.suggest_int(k, *v)
                  for k, v in space.items()}
        signals = backtest_signals(data, strategy, params)
        metrics = compute_metrics(signals)
        return metrics['sharpe_ratio']

    study = optuna.create_study(direction='maximize')
    study.optimize(objective, n_trials=50)
    trials_df = study.trials_dataframe(attrs=("params", "value"))
    trials_df.to_csv(PARAM_DIR / f"param_grid_{strategy}.csv", index=False)

def compute_metrics(signals: pd.DataFrame) -> Dict[str, Any]:
    return {'sharpe_ratio': signals['returns'].mean() / signals['returns'].std()}
