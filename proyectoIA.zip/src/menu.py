#!/usr/bin/env python3
import subprocess
import sys
from config import Config

def load_strategies():
    cfg = Config.load('config/config.yaml')
    return list(cfg.parameters.keys())

MENU = [
    ('Optimizar parámetros', 'optimize', ['strategy']),
    ('Validar parámetros', 'validar_parametros', []),
    ('Entrenar modelos',   'entrenar', []),
    ('Generar señales',    'generar_senales', ['periodo']),
    ('Ajustar riesgo',     'tune_risk_confianza', []),
    ('Búsqueda fina SL/TP','grid_search_sharpe', []),
    ('Evaluar rentabilidad','evaluar_rentabilidad', []),
    ('Salir', None, [])
]

def print_menu():
    print("\n=== Menú Trading IA ===")
    for i, (label, _, _) in enumerate(MENU, 1):
        print(f"{i}. {label}")

def main():
    strategies = load_strategies()
    while True:
        print_menu()
        choice = input("Selecciona una opción (número): ")
        if not choice.isdigit() or not (1 <= int(choice) <= len(MENU)):
            print("Opción inválida. Intenta de nuevo.")
            continue
        idx = int(choice) - 1
        label, cmd, params = MENU[idx]
        if cmd is None:
            print("Saliendo...")
            sys.exit(0)
        args = ['python', 'src/cli.py', cmd]
        for p in params:
            if p == 'strategy':
                strat = input(f"  Estrategia ({', '.join(strategies)}): ")
                args.append(strat)
            elif p == 'periodo':
                periodo = input("  Periodo (YYYY-MM-DD:YYYY-MM-DD): ")
                args.extend(['--periodo', periodo])
        print(f"Ejecutando: {' '.join(args)}\n")
        subprocess.run(args)

if __name__ == '__main__':
    main()
